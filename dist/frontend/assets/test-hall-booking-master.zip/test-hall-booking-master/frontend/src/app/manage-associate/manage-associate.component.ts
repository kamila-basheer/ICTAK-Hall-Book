import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { AssociateModel } from './associatemodel';

@Component({
  selector: 'app-manage-associate',
  templateUrl: './manage-associate.component.html',
  styleUrls: ['./manage-associate.component.css']
})
export class ManageAssociateComponent implements OnInit {
  associate :any
  title:String="Associate Details";
  associates:AssociateModel[] = [];
  associatesLength:any
  setitem(item:any){
    localStorage.setItem("Item",item)
     }
   
     removeitem(){
       localStorage.removeItem("Item")
     }

  constructor(private authService:AuthService, private router: Router) { }

  ngOnInit(): void {

    this.authService.getAssociates()
     .subscribe((data)=>{
      this.associates = JSON.parse(JSON.stringify(data));
      this.associatesLength=this.associates.length;
     },err=>{
      console.log(err.error.message);
      if(err.error.message=='Unauthorized'){
      this.router.navigate(['home']);}
      // this.errors=err.error.message;
      // alert(this.errors);
      // this.router.navigate(['home']);

    })
  }

  deleteAssociate(){
    this.associate =  localStorage.getItem("Item");
    console.log(this.associate);
    this.authService.deleteAssociate(this.associate)
      .subscribe((data)=>{
        window.location.reload();
      },err=>{
        console.log(err.error.message);
        if(err.error.message=='Unauthorized'){
        this.router.navigate(['']);}
        // this.errors=err.error.message;
        // alert(this.errors);
        // this.router.navigate(['home']);
  
      })
  }

  updateBook(book:any){
    console.log(book);
    localStorage.setItem("editAssociateId", book);
    this.router.navigate(['admin-dashboard/edit-associate']);
  }

}
