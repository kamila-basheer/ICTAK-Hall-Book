import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AuthGuard} from './auth.guard'
import { BookHallComponent } from './book-hall/book-hall.component';
import { EditAssociateComponent } from './edit-associate/edit-associate.component';
import { EditBookingComponent } from './edit-booking/edit-booking.component';
import { EditCalendarComponent } from './edit-calendar/edit-calendar.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ManageAssociateComponent } from './manage-associate/manage-associate.component';
import { ManageBookingComponent } from './manage-booking/manage-booking.component';
import { SignupComponent } from './signup/signup.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ViewCalendarComponent } from './view-calendar/view-calendar.component';


const routes: Routes = [
  {path:"book-your-hall",canActivate:[AuthGuard],component:BookHallComponent},
  {path:"view-calendar",canActivate:[AuthGuard], component:ViewCalendarComponent},
  {path:"dashboard",canActivate:[AuthGuard], component:UserDashboardComponent  },
  {path:"edit-calendar",canActivate:[AuthGuard], component:EditCalendarComponent},
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:'',component:HomeComponent},
  {path:'admin-login',component:AdminLoginComponent},
  {path:'admin-dashboard',canActivate:[AuthGuard],component:AdminDashboardComponent,
children:[
  {path:'manage-bookings',canActivate:[AuthGuard],component:ManageBookingComponent},
  {path:'edit-booking/:id',canActivate:[AuthGuard],component:EditBookingComponent},
  {path:'manage-associates',canActivate:[AuthGuard],component:ManageAssociateComponent},
  {path:'home',component:AdminHomeComponent},
  {path:'edit-associate',component:EditAssociateComponent}]}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
