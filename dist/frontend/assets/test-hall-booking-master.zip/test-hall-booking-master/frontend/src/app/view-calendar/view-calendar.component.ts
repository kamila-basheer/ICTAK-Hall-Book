import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/angular'; // useful for typechecking
import { BookingService } from '../booking.service';


@Component({
  selector: 'app-view-calendar',
  templateUrl: './view-calendar.component.html',
  styleUrls: ['./view-calendar.component.css']
})
export class ViewCalendarComponent implements OnInit {

  calendarOptions: CalendarOptions = {
    initialView: 'dayGridMonth',
    // events: [
    //   { title: 'event 1', date: '2022-07-24' },
    //   { title: 'event 1.2', date: '2022-07-24' },
    //   { title: 'event 2', date: '2019-04-02' }
    // ]
    events:''

    
  };
  bookings:any
  i:any
  slots:Array<any>=[]
  limit:Number =0
  count:number=0
  booking={
    title:'',
    date:'',
    backgroundColor:'',
    display:'',
    
  }
  from:any
  




  constructor(private bookingservice:BookingService ) { }

  ngOnInit(): void {
    this.bookingservice.getbookingdetails()
    .subscribe(res=>{
      this.bookings=res;
      console.log(this.bookings[0].Date);
      this.limit = this.bookings.length;

      for (this.i of this.bookings)
      {
        this.from=this.i.fromTime.split("T")[1];
        this.from=this.from.split(".")[0];
        this.booking.title=this.i.hallName;
        this.booking.date=this.i.Date.split("T")[0];
        this.booking.backgroundColor="green";
        this.booking.display="auto";
        this.slots.push(this.booking);
        this.booking={title:'',date:'', backgroundColor:'',display:''}
        this.from=this.i.fromTime.split("T")[1];
        this.from=this.from.split(".")[0];
      }
      this.calendarOptions.events=this.slots;
      console.log(this.from)
    })
  }

}
