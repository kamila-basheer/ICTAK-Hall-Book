import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  errors=null
  loginAdminData = {username:'',
  password:'',
  
  };

  constructor(private _auth:AuthService, public router:Router) { }

  ngOnInit(): void {
  }
  loginAdmin(){
    this.errors=null
    console.log(this.loginAdminData);
    this._auth.loginAdmin(this.loginAdminData)
    .subscribe (res=>{
      
      console.log(res);
      localStorage.setItem('token', res.token);
      this.router.navigate(['admin-dashboard']);
      },
      err=>{
        this.errors=err.error.message;
        console.log(this.errors);
      }
    )

    
  }

}
