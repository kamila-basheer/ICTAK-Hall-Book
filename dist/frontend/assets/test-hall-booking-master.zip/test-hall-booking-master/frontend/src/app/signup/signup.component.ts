import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  errors=null

  registerUserData = {username:'',
  email:'',
  password:'',
  confirmPassword:''
  };
  err:any;

  constructor( private router:Router, private auth:AuthService) { }

  ngOnInit(): void {
  }

  registerUser(){
    this.err=null
    console.log(this.registerUserData);
    this.auth.registerUser(this.registerUserData)
    .subscribe (
      res=>{
      localStorage.setItem('token', res.token);
      this.router.navigate(['/dashboard']);
    },
    err=>{
      console.log(err.error.message);
        this.err = err.error.message;
    })
   
}

}