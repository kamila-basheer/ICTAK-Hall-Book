export class AssociateModel{
    constructor(
       public _id:String,
       public Name: String,
       public Email: String,
       public Password: String
      
    ) { }
}