import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginUserData = {username:'',
  password:'',
  };
id:any;
message:any
  constructor(public router:Router, private auth:AuthService) { }

  ngOnInit(): void {
  }

  loginUser(){
    this.message=null;
    this.auth.loginUser(this.loginUserData)
    .subscribe (
      res=>{
      this.id=JSON.parse(JSON.stringify(res.token));
      // this.id = res.id;
      localStorage.setItem('token', res.token);
      this.router.navigate(['/dashboard']);
      },
      err=>{
        console.log(err.error.message);
        this.message = err.error.message;
      }
      
    )
    
    
    
  }

}
